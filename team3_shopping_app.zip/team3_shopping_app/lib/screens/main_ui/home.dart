import 'package:flutter/material.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:team3_shopping_app/constants/theme.dart';
import 'package:team3_shopping_app/models/categoryModel.dart';

import '../../models/product_model.dart';
import '../../widgets/top_titles/top_titles.dart';

class HomePage extends StatefulWidget {
  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<String> imageUrls = [
    'assets/images/laptop/laptop2.jpg',
    'assets/images/laptop/laptop1.jpg',
    'assets/images/mouse/mouse1.jpg',
    // Add other image URLs here
  ];

  int currentIndex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Toptiles(),
            SizedBox(height: 20),
            CarouselSlider(
              items: imageUrls.map((url) {
                return Image.asset(
                  url,
                  fit: BoxFit.cover,
                  height: 300,
                  width: 300,
                );
              }).toList(),
              options: CarouselOptions(
                height: 300,
                initialPage: currentIndex,
                autoPlay: true,
                onPageChanged: (index, reason) {
                  setState(() {
                    currentIndex = index;
                  });
                },
              ),
            ),
            Padding(
              padding: EdgeInsets.all(15.0),
              child: Text(
                "Categories",
                style: TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              child: Row(
                children: categoriesList.map((category) {
                  return Padding(
                    padding: const EdgeInsets.only(left: 8.0),
                    child: Card(
                      color: Colors.white,
                      elevation: 6.0,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20.0),
                      ),
                      child: SizedBox(
                        height: 100,
                        width: 100,
                        child: Image.asset(category.image),
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
            Padding(
              padding: EdgeInsets.all(15.0),
              child: Text(
                "Best Seller",
                style: TextStyle(
                  fontSize: 16.0,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(12.0),
              child: GridView.builder(
                padding: EdgeInsets.zero,
                shrinkWrap: true,
                itemCount: bestProducts.length,
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  mainAxisSpacing: 20,
                  crossAxisSpacing: 20,
                  crossAxisCount: 2,
                  childAspectRatio: 0.7,
                ),
                itemBuilder: (ctx, index) {
                  ProductModel singleProduct = bestProducts[index];
                  return Container(
                    decoration: BoxDecoration(
                      color: Colors.grey.withOpacity(0.2),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.grey.withOpacity(0.1),
                          spreadRadius: 2,
                          blurRadius: 4,
                          offset: Offset(0, 2), // Adjust the offset as needed
                        ),
                      ],
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center, // Center vertically
                      children: [
                        Image.asset(
                          singleProduct.image,
                          height: 60,
                          width: 60,
                        ),
                        SizedBox(height: 12.0),
                        Text(
                          singleProduct.name,
                          style: TextStyle(
                            fontSize: 12.0,
                            fontWeight: FontWeight.bold,
                          ),
                          textAlign: TextAlign.center, // Center horizontally
                        ),
                        Text(
                          "Price: ${singleProduct.price}",
                          textAlign: TextAlign.center, // Center horizontally
                        ),
                        SizedBox(height: 6.0),
                        OutlinedButton(
                          onPressed: () {},
                          style: OutlinedButton.styleFrom(
                            backgroundColor: Colors.redAccent,
                            side: BorderSide(
                              color: Colors.redAccent,
                              width: 1.4,
                            ),
                            fixedSize: Size(150, 40), // Set the desired width and height
                          ),
                          child: Text(
                            "Buy",
                            style: TextStyle(
                              color: Colors.white,
                            ),
                          ),
                        )
                      ],
                    ),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

List<CategoryModel> categoriesList = [
  CategoryModel(
      id: "1",
      image: "assets/images/category/laptop.jpg",
  ),
  CategoryModel(
    id: "2",
    image: "assets/images/category/iphone.jpg",
  ),
  CategoryModel(
    id: "3",
    image: "assets/images/category/monitor.jpg",
  ),
  CategoryModel(
    id: "4",
    image: "assets/images/category/mouse.jpg",
  ),
  CategoryModel(
    id: "5",
    image: "assets/images/category/camera.jpg",
  ),
  CategoryModel(
    id: "6",
    image: "assets/images/category/clothes.jpg",
  ),
];

List<ProductModel> bestProducts = [
  ProductModel(
      image: "assets/images/laptop/laptop3.jpg",
      id: "1",
      name: "Acer Nitro 5 AN515-58-57Y8",
      price: "810",
      description: "Take your game to the next level with the 12th Gen Intel Core i5 processor. Get immersive and competitive performance for all your games.",
      isFavorite: false,
      status: "pending"
  ),
  ProductModel(
      image: "assets/images/mouse/mouse2.jpg",
      id: "2",
      name: "Razer DeathAdder Essential Gaming Mouse",
      price: "750",
      description: "High-Precision 6,400 DPI Optical Sensor",
      isFavorite: false,
      status: "pending"
  ),
  ProductModel(
      image: "assets/images/laptop/laptop2.jpg",
      id: "3",
      name: "SAMSUNG 15.6” Galaxy Book3",
      price: "680 ",
      description: "ELEVATE YOUR EVERYDAY: Welcome to power, Galaxy style;",
      isFavorite: false,
      status: "pending"
  ),
];