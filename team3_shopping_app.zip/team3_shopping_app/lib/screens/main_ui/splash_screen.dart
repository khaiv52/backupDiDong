import 'dart:async';

import 'package:flutter/material.dart';
import 'package:team3_shopping_app/screens/auth_ui/login/login.dart';

class SplashScreen extends StatelessWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            // Hiển thị biểu tượng của ứng dụng ở đây
            Image.asset('assets/images/logo-color.png', width: 100, height: 100),
          ],
        ),
      ),
    );
  }
}

class SplashScreenWrapper extends StatefulWidget {
  const SplashScreenWrapper({Key? key}) : super(key: key);

  @override
  _SplashScreenWrapperState createState() => _SplashScreenWrapperState();
}

class _SplashScreenWrapperState extends State<SplashScreenWrapper> {
  @override
  void initState() {
    super.initState();
    // Sử dụng Future.delayed để tạo hiệu ứng delay
    Future.delayed(Duration(seconds: 10), () {
      // Chuyển đến trang Login khi ứng dụng đã sẵn sàng
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(builder: (context) => const LoginPage()),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return SplashScreen();
  }
}
