import 'package:flutter/material.dart';

class Toptiles extends StatelessWidget {
  const Toptiles({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AppBar(
      leading: IconButton(
        icon: Icon(Icons.arrow_back),
        onPressed: () {
          // Xử lý khi người dùng nhấn nút back
          Navigator.pop(context);
        },
      ),
      title: Container(
        margin: EdgeInsets.only(top: 10),
        child: Row(
          children: [
            Expanded(
              child: Container(
                margin: EdgeInsets.only(bottom: 10),
                child: TextField(
                  decoration: InputDecoration(
                    hintText: 'Tìm kiếm...',
                    hintStyle: TextStyle(color: Colors.white),
                  ),
                  style: TextStyle(color: Colors.white),
                ),
              ),
            ),
            Container(
              margin: EdgeInsets.only(bottom: 10, left: 8),
              child: IconButton(
                icon: Icon(Icons.search),
                onPressed: () {
                  // Xử lý khi người dùng nhấn nút search
                  Navigator.pop(context);
                },
                padding: EdgeInsets.all(0),
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
      backgroundColor: Colors.redAccent,
      actions: [
        IconButton(
          icon: Icon(Icons.person),
          onPressed: () {
            // Xử lý khi người dùng nhấn nút user
          },
          color: Colors.white,
        ),
        IconButton(
          icon: Icon(Icons.shopping_cart),
          onPressed: () {
            // Xử lý khi người dùng nhấn nút cart
          },
          color: Colors.white,
        ),
        IconButton(
          icon: Icon(Icons.list_alt),
          onPressed: () {
            // Xử lý khi người dùng nhấn nút order
          },
          color: Colors.white,
        ),
      ],
      iconTheme: IconThemeData(color: Colors.white),
      titleTextStyle: TextStyle(color: Colors.white, fontSize: 20),
    );
  }
}
