import 'dart:convert';

class ProductModel {
  ProductModel({
    required this.image,
    required this.id,
    required this.name,
    required this.price,
    required this.description,
    required this.isFavorite,
    required this.status,

  });

  String image;
  String id;
  bool isFavorite;
  String name;
  String price;
  String description;
  String status;

  factory ProductModel.fromJson(Map<String, dynamic> json) => ProductModel(
    id: json["name"],
    name: json["email"],
    description: json["description"],
    image: json["image"],
    isFavorite: false,
    price: json["price"],
    status: json["status"],
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "name": name,
    "description": description,
    "image" : image,
    "isFavorite" : isFavorite,
    "price" : price,
    "status" : status,
  };
}

// You had UserModel here, but it should be ProductModel
String productModelToJson(ProductModel data) => json.encode(data.toJson());

ProductModel productModelFromJson(String str) =>
    ProductModel.fromJson(json.decode(str));
