class AssetImages {
  static AssetImages instance = AssetImages();
  static const String _imagesPath = "assets/images/";

  final String box_red = "$_imagesPath/box_red.png";
  final String wave = "$_imagesPath/wave.png";
}