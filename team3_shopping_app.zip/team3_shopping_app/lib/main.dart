import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:team3_shopping_app/screens/auth_ui/controller/auth_controller.dart';
import 'package:team3_shopping_app/screens/auth_ui/login/login.dart';
import 'package:team3_shopping_app/screens/auth_ui/sign_up/sign_up.dart';
import 'package:team3_shopping_app/screens/main_ui/splash_screen.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp();
    Get.put(AuthController());
    runApp(const MyApp());
  } catch (e) {
    print('Error initializing Firebase: $e');
    // Xử lý lỗi khởi tạo Firebase ở đây nếu cần thiết
  }
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return const GetMaterialApp(
      title: 'Shopping App',
      home: SplashScreenWrapper(),
    );
  }
}
